// Stripe configuration
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

// Initialize Stripe with your publishable key
// In a real app, this would come from an environment variable
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '');

// Export the Stripe promise for use in components
export { stripePromise };

// Types for credit packages
export type CreditPackage = {
  id: string;
  name: string;
  credits: number;
  price: number; // in cents
  description?: string;
  popular?: boolean;
};

// Define credit packages
export const creditPackages: CreditPackage[] = [
  {
    id: 'basic',
    name: 'Basic',
    credits: 500,
    price: 499, // $4.99
    description: 'Perfect for occasional use'
  },
  {
    id: 'standard',
    name: 'Standard',
    credits: 2000,
    price: 1499, // $14.99
    description: 'Most popular choice',
    popular: true
  },
  {
    id: 'premium',
    name: 'Premium',
    credits: 5000,
    price: 2999, // $29.99
    description: 'Best value for power users'
  },
  {
    id: 'ultimate',
    name: 'Ultimate',
    credits: 12000,
    price: 5999, // $59.99
    description: 'For professional creators'
  }
];

// Types for subscription plans
export type SubscriptionPlan = {
  id: string;
  name: string;
  creditsPerMonth: number;
  price: number; // in cents
  features: string[];
  popular?: boolean;
};

// Define subscription plans
export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    creditsPerMonth: 1000,
    price: 999, // $9.99/month
    features: [
      '1,000 credits per month',
      'Basic image processing',
      'Standard support'
    ]
  },
  {
    id: 'pro',
    name: 'Professional',
    creditsPerMonth: 5000,
    price: 2499, // $24.99/month
    features: [
      '5,000 credits per month',
      'Advanced image processing',
      'Priority support',
      'HD video exports'
    ],
    popular: true
  },
  {
    id: 'business',
    name: 'Business',
    creditsPerMonth: 15000,
    price: 4999, // $49.99/month
    features: [
      '15,000 credits per month',
      'Premium image processing',
      '24/7 dedicated support',
      '4K video exports',
      'Team collaboration tools'
    ]
  }
];

// Function to format price from cents to dollars
export const formatPrice = (price: number): string => {
  return `$${(price / 100).toFixed(2)}`;
};
