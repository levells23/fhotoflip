"use client";

import { useState } from "react";

// This is a mock implementation of the authentication service
// In a real application, this would connect to a backend API
export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Create a new user with initial credits
      const newUser: User = {
        id: `user_${Date.now()}`,
        name,
        email,
        credits: 1000,
        createdAt: new Date().toISOString(),
        projects: []
      };
      
      // Store user in localStorage (in a real app, this would be handled by a backend)
      localStorage.setItem('fhotoflip_user', JSON.stringify(newUser));
      setUser(newUser);
      return true;
    } catch (err) {
      setError('Failed to create account. Please try again.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, this would validate credentials against a backend
      // For demo purposes, we'll just check if a user exists in localStorage
      const storedUser = localStorage.getItem('fhotoflip_user');
      
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser) as User;
        if (parsedUser.email === email) {
          setUser(parsedUser);
          return true;
        }
      }
      
      setError('Invalid email or password');
      return false;
    } catch (err) {
      setError('Failed to log in. Please try again.');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    // In a real app, this would also invalidate the session on the backend
  };

  const addCredits = (amount: number) => {
    if (!user) return;
    
    const updatedUser = {
      ...user,
      credits: user.credits + amount
    };
    
    setUser(updatedUser);
    localStorage.setItem('fhotoflip_user', JSON.stringify(updatedUser));
  };

  const useCredits = (amount: number): boolean => {
    if (!user || user.credits < amount) return false;
    
    const updatedUser = {
      ...user,
      credits: user.credits - amount
    };
    
    setUser(updatedUser);
    localStorage.setItem('fhotoflip_user', JSON.stringify(updatedUser));
    return true;
  };

  const addReferralCredits = () => {
    addCredits(500);
  };

  return {
    user,
    loading,
    error,
    signup,
    login,
    logout,
    addCredits,
    useCredits,
    addReferralCredits
  };
};

// Types
export interface User {
  id: string;
  name: string;
  email: string;
  credits: number;
  createdAt: string;
  projects: Project[];
}

export interface Project {
  id: string;
  name: string;
  type: 'video' | 'watermark' | 'enhance' | 'film';
  createdAt: string;
  thumbnailUrl?: string;
  outputUrl?: string;
}
