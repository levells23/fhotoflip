"use client";

import { useState } from "react";
import { useAuthContext } from "@/context/auth-context";
import { FhotoflipLogo } from "@/components/icons/logo";

export default function SocialShareService() {
  const { user, addReferralCredits } = useAuthContext();
  
  const shareToFacebook = (url: string, title: string) => {
    const shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(title)}`;
    window.open(shareUrl, '_blank', 'width=600,height=400');
    return true;
  };
  
  const shareToTwitter = (url: string, title: string) => {
    const shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`;
    window.open(shareUrl, '_blank', 'width=600,height=400');
    return true;
  };
  
  const shareToInstagram = () => {
    // Instagram doesn't support direct sharing via URL
    // Usually requires a mobile app or Instagram API
    // For demo purposes, we'll show a message about copying the link
    alert("Instagram sharing requires the mobile app. Please download your creation and share it via the Instagram app.");
    return true;
  };
  
  const generateShareableLink = (projectId: string) => {
    // In a real app, this would generate a unique, trackable link
    return `https://fhotoflip.com/share/${projectId}`;
  };
  
  const trackReferralShare = async (platform: string) => {
    if (!user) return false;
    
    try {
      // In a real app, this would call an API to track the share
      // For demo purposes, we'll just add the referral credits
      addReferralCredits();
      return true;
    } catch (error) {
      console.error("Error tracking share:", error);
      return false;
    }
  };
  
  return {
    shareToFacebook,
    shareToTwitter,
    shareToInstagram,
    generateShareableLink,
    trackReferralShare
  };
}
