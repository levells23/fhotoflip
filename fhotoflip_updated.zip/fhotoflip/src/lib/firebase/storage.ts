import { storage } from './firebase';
import { 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  deleteObject,
  listAll,
  UploadMetadata
} from 'firebase/storage';

// Upload a file to Firebase Storage
export const uploadFile = async (
  file: File, 
  path: string, 
  metadata?: UploadMetadata
): Promise<string> => {
  try {
    const storageRef = ref(storage, path);
    const uploadResult = await uploadBytes(storageRef, file, metadata);
    const downloadURL = await getDownloadURL(uploadResult.ref);
    return downloadURL;
  } catch (error: any) {
    throw new Error(`Error uploading file: ${error.message}`);
  }
};

// Upload a file from a data URL (base64)
export const uploadFromDataURL = async (
  dataURL: string,
  path: string,
  metadata?: UploadMetadata
): Promise<string> => {
  try {
    // Convert data URL to blob
    const response = await fetch(dataURL);
    const blob = await response.blob();
    
    // Upload blob to Firebase Storage
    const storageRef = ref(storage, path);
    const uploadResult = await uploadBytes(storageRef, blob, metadata);
    const downloadURL = await getDownloadURL(uploadResult.ref);
    return downloadURL;
  } catch (error: any) {
    throw new Error(`Error uploading from data URL: ${error.message}`);
  }
};

// Get download URL for a file
export const getFileURL = async (path: string): Promise<string> => {
  try {
    const storageRef = ref(storage, path);
    return await getDownloadURL(storageRef);
  } catch (error: any) {
    throw new Error(`Error getting file URL: ${error.message}`);
  }
};

// Delete a file from Firebase Storage
export const deleteFile = async (path: string): Promise<boolean> => {
  try {
    const storageRef = ref(storage, path);
    await deleteObject(storageRef);
    return true;
  } catch (error: any) {
    throw new Error(`Error deleting file: ${error.message}`);
  }
};

// List all files in a directory
export const listFiles = async (path: string): Promise<string[]> => {
  try {
    const storageRef = ref(storage, path);
    const result = await listAll(storageRef);
    
    // Get download URLs for all items
    const urls = await Promise.all(
      result.items.map(itemRef => getDownloadURL(itemRef))
    );
    
    return urls;
  } catch (error: any) {
    throw new Error(`Error listing files: ${error.message}`);
  }
};

// Helper function to generate a unique file path
export const generateFilePath = (userId: string, fileName: string, folder: string = 'uploads'): string => {
  const timestamp = Date.now();
  const extension = fileName.split('.').pop();
  return `${folder}/${userId}/${timestamp}.${extension}`;
};
