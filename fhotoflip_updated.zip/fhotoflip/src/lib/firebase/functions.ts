import { functions } from './firebase';
import { httpsCallable } from 'firebase/functions';

// Define types for the AI processing functions
type ProcessingOptions = {
  quality?: 'standard' | 'high' | 'ultra';
  duration?: number;
  style?: string;
  prompt?: string;
};

// Function to generate video from image
export const generateVideo = async (
  imageUrl: string,
  options: ProcessingOptions = {}
) => {
  try {
    const generateVideoFunction = httpsCallable(functions, 'generateVideo');
    const result = await generateVideoFunction({
      imageUrl,
      options
    });
    return result.data;
  } catch (error: any) {
    throw new Error(`Error generating video: ${error.message}`);
  }
};

// Function to remove watermark from image
export const removeWatermark = async (
  imageUrl: string,
  options: ProcessingOptions = {}
) => {
  try {
    const removeWatermarkFunction = httpsCallable(functions, 'removeWatermark');
    const result = await removeWatermarkFunction({
      imageUrl,
      options
    });
    return result.data;
  } catch (error: any) {
    throw new Error(`Error removing watermark: ${error.message}`);
  }
};

// Function to enhance image quality
export const enhanceImage = async (
  imageUrl: string,
  options: ProcessingOptions = {}
) => {
  try {
    const enhanceImageFunction = httpsCallable(functions, 'enhanceImage');
    const result = await enhanceImageFunction({
      imageUrl,
      options
    });
    return result.data;
  } catch (error: any) {
    throw new Error(`Error enhancing image: ${error.message}`);
  }
};

// Function for filmmaking tools
export const applyFilmEffect = async (
  imageUrl: string,
  options: ProcessingOptions = {}
) => {
  try {
    const applyFilmEffectFunction = httpsCallable(functions, 'applyFilmEffect');
    const result = await applyFilmEffectFunction({
      imageUrl,
      options
    });
    return result.data;
  } catch (error: any) {
    throw new Error(`Error applying film effect: ${error.message}`);
  }
};

// Function to track credit usage
export const trackCreditUsage = async (
  userId: string,
  operation: string,
  creditsUsed: number
) => {
  try {
    const trackCreditUsageFunction = httpsCallable(functions, 'trackCreditUsage');
    const result = await trackCreditUsageFunction({
      userId,
      operation,
      creditsUsed
    });
    return result.data;
  } catch (error: any) {
    throw new Error(`Error tracking credit usage: ${error.message}`);
  }
};
