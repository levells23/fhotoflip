import { db } from './firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where,
  orderBy,
  limit,
  Timestamp,
  DocumentData
} from 'firebase/firestore';

// User profile functions
export const createUserProfile = async (userId: string, userData: any) => {
  try {
    // Add initial credits when creating a user profile
    const userProfile = {
      ...userData,
      credits: 1000, // Initial free credits
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };
    
    await setDoc(doc(db, 'users', userId), userProfile);
    return userProfile;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const getUserProfile = async (userId: string) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      return { id: userDoc.id, ...userDoc.data() };
    } else {
      return null;
    }
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const updateUserProfile = async (userId: string, userData: any) => {
  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      ...userData,
      updatedAt: Timestamp.now()
    });
    return true;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

// Credits management
export const addCredits = async (userId: string, amount: number) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error('User not found');
    }
    
    const currentCredits = userDoc.data().credits || 0;
    
    await updateDoc(userRef, {
      credits: currentCredits + amount,
      updatedAt: Timestamp.now()
    });
    
    // Log the transaction
    await setDoc(doc(collection(db, 'creditTransactions')), {
      userId,
      amount,
      type: 'add',
      reason: 'purchase',
      timestamp: Timestamp.now()
    });
    
    return currentCredits + amount;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const useCredits = async (userId: string, amount: number) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error('User not found');
    }
    
    const currentCredits = userDoc.data().credits || 0;
    
    if (currentCredits < amount) {
      throw new Error('Insufficient credits');
    }
    
    await updateDoc(userRef, {
      credits: currentCredits - amount,
      updatedAt: Timestamp.now()
    });
    
    // Log the transaction
    await setDoc(doc(collection(db, 'creditTransactions')), {
      userId,
      amount: -amount,
      type: 'use',
      reason: 'processing',
      timestamp: Timestamp.now()
    });
    
    return currentCredits - amount;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const addReferralCredits = async (userId: string) => {
  try {
    const referralAmount = 500; // Bonus credits for sharing
    return await addCredits(userId, referralAmount);
  } catch (error: any) {
    throw new Error(error.message);
  }
};

// Project management
export const createProject = async (userId: string, projectData: any) => {
  try {
    const projectRef = doc(collection(db, 'projects'));
    const project = {
      ...projectData,
      userId,
      createdAt: Timestamp.now(),
      updatedAt: Timestamp.now()
    };
    
    await setDoc(projectRef, project);
    return { id: projectRef.id, ...project };
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const getUserProjects = async (userId: string) => {
  try {
    const projectsQuery = query(
      collection(db, 'projects'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(projectsQuery);
    const projects: DocumentData[] = [];
    
    querySnapshot.forEach((doc) => {
      projects.push({ id: doc.id, ...doc.data() });
    });
    
    return projects;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const getProject = async (projectId: string) => {
  try {
    const projectDoc = await getDoc(doc(db, 'projects', projectId));
    if (projectDoc.exists()) {
      return { id: projectDoc.id, ...projectDoc.data() };
    } else {
      return null;
    }
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const updateProject = async (projectId: string, projectData: any) => {
  try {
    const projectRef = doc(db, 'projects', projectId);
    await updateDoc(projectRef, {
      ...projectData,
      updatedAt: Timestamp.now()
    });
    return true;
  } catch (error: any) {
    throw new Error(error.message);
  }
};

export const deleteProject = async (projectId: string) => {
  try {
    await deleteDoc(doc(db, 'projects', projectId));
    return true;
  } catch (error: any) {
    throw new Error(error.message);
  }
};
