"use client";

import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { useAuth, User } from "@/lib/auth";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  addCredits: (amount: number) => void;
  useCredits: (amount: number) => boolean;
  addReferralCredits: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const auth = useAuth();
  const [initialized, setInitialized] = useState(false);

  // Check for existing user session on initial load
  useEffect(() => {
    const checkExistingUser = async () => {
      try {
        const storedUser = localStorage.getItem('fhotoflip_user');
        if (storedUser) {
          // In a real app, this would validate the session with the backend
          // For demo purposes, we'll just use the stored user data
          await auth.login(JSON.parse(storedUser).email, "");
        }
      } catch (error) {
        console.error("Error checking existing user:", error);
      } finally {
        setInitialized(true);
      }
    };

    checkExistingUser();
  }, []);

  if (!initialized) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <AuthContext.Provider value={auth}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuthContext must be used within an AuthProvider");
  }
  return context;
}
