import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User } from 'firebase/auth';
import { onAuthStateChange, getCurrentUser } from '../lib/firebase/auth';
import { getUserProfile, createUserProfile } from '../lib/firebase/firestore';

// Define the shape of our Firebase context
interface FirebaseContextType {
  user: User | null;
  userProfile: any | null;
  loading: boolean;
  error: string | null;
}

// Create the context with a default value
const FirebaseContext = createContext<FirebaseContextType>({
  user: null,
  userProfile: null,
  loading: true,
  error: null
});

// Provider component that wraps the app and makes auth object available to any child component
export function FirebaseProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChange(async (authUser) => {
      setLoading(true);
      
      try {
        if (authUser) {
          setUser(authUser);
          
          // Get user profile from Firestore
          const profile = await getUserProfile(authUser.uid);
          
          // If profile doesn't exist, create one
          if (!profile) {
            const newProfile = await createUserProfile(authUser.uid, {
              displayName: authUser.displayName || '',
              email: authUser.email || '',
              photoURL: authUser.photoURL || ''
            });
            setUserProfile(newProfile);
          } else {
            setUserProfile(profile);
          }
        } else {
          setUser(null);
          setUserProfile(null);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    });

    // Cleanup subscription on unmount
    return () => unsubscribe();
  }, []);

  return (
    <FirebaseContext.Provider value={{ user, userProfile, loading, error }}>
      {children}
    </FirebaseContext.Provider>
  );
}

// Custom hook to use the Firebase context
export const useFirebase = () => {
  return useContext(FirebaseContext);
};
