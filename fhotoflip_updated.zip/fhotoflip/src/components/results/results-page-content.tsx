"use client";

import { useState } from "react";
import { FhotoflipLogo } from "@/components/icons/logo";
import { useAuthContext } from "@/context/auth-context";
import SocialShareButtons from "@/components/ui/social-share-buttons";

export default function ResultsPage({ resultUrl, processingType }: { resultUrl: string, processingType: string }) {
  const { user } = useAuthContext();
  const [showShareModal, setShowShareModal] = useState(false);
  
  if (!user) {
    return null;
  }
  
  // Generate a unique project ID for sharing
  const projectId = `${processingType}_${Date.now().toString().slice(-6)}`;
  
  return (
    <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8 max-w-4xl w-full mx-auto">
      <div className="flex items-center justify-center mb-6">
        <FhotoflipLogo className="h-8 w-auto mr-2" />
        <h2 className="text-2xl font-bold">Your Transformation Result</h2>
      </div>
      
      <div className="mb-8">
        <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden mb-4">
          {processingType === 'video' || processingType === 'film' ? (
            <video 
              src={resultUrl} 
              controls 
              className="w-full h-full object-contain"
              autoPlay
              loop
            />
          ) : (
            <img 
              src={resultUrl} 
              alt="Processed result" 
              className="w-full h-full object-contain" 
            />
          )}
        </div>
        
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-medium">
            {processingType === 'video' ? 'Photo to Video' : 
             processingType === 'watermark' ? 'Watermark Removed' :
             processingType === 'enhance' ? 'Enhanced Image' : 'Film Creation'}
          </h3>
          <div className="flex space-x-3">
            <button 
              onClick={() => setShowShareModal(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg hover:opacity-90 transition flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              Share
            </button>
            <a 
              href={resultUrl} 
              download
              className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/20 transition flex items-center"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Download
            </a>
          </div>
        </div>
      </div>
      
      {showShareModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="relative">
            <button 
              onClick={() => setShowShareModal(false)}
              className="absolute -top-12 right-0 text-white hover:text-gray-300"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <SocialShareButtons projectId={projectId} title={`Check out my ${processingType} creation on Fhotoflip!`} />
          </div>
        </div>
      )}
      
      <div className="border-t border-gray-800 pt-6 mt-6">
        <h3 className="text-lg font-medium mb-4">Create something new</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <a 
            href="/upload"
            className="p-3 rounded-lg border border-gray-700 hover:border-purple-500 hover:bg-purple-500/10 transition text-center"
          >
            Photo to Video
          </a>
          <a 
            href="/upload"
            className="p-3 rounded-lg border border-gray-700 hover:border-purple-500 hover:bg-purple-500/10 transition text-center"
          >
            Watermark Removal
          </a>
          <a 
            href="/upload"
            className="p-3 rounded-lg border border-gray-700 hover:border-purple-500 hover:bg-purple-500/10 transition text-center"
          >
            Image Enhancement
          </a>
          <a 
            href="/upload"
            className="p-3 rounded-lg border border-gray-700 hover:border-purple-500 hover:bg-purple-500/10 transition text-center"
          >
            Filmmaking Tools
          </a>
        </div>
      </div>
    </div>
  );
}
