"use client";

import { useEffect, useState } from 'react';
import Navbar from '@/components/ui/navbar';
import Footer from '@/components/ui/footer';
import BreadcrumbNavigation from '@/components/ui/breadcrumb';
import { useFirebase } from '@/context/firebase-context';
import { useRouter } from 'next/navigation';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useFirebase();
  const router = useRouter();
  const [isPageLoading, setIsPageLoading] = useState(true);
  
  useEffect(() => {
    // Wait for Firebase auth to initialize
    if (!loading) {
      setIsPageLoading(false);
    }
  }, [loading]);
  
  if (isPageLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-black to-purple-900/20 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow pt-16 md:pt-20">
        <BreadcrumbNavigation />
        {children}
      </main>
      <Footer />
    </div>
  );
}
