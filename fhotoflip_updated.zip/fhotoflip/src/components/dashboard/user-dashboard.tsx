"use client";

import { useState } from "react";
import { FhotoflipLogo } from "@/components/icons/logo";
import { useAuthContext } from "@/context/auth-context";
import { useRouter } from "next/navigation";

export default function UserDashboard() {
  const { user, logout } = useAuthContext();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState("projects");
  
  if (!user) {
    router.push("/login");
    return null;
  }
  
  const userCredits = user.credits;
  const userName = user.name;
  
  return (
    <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-6 max-w-4xl w-full mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div className="flex items-center">
          <FhotoflipLogo className="h-8 w-auto mr-3" />
          <div>
            <h2 className="text-2xl font-bold">My Dashboard</h2>
            <p className="text-gray-400">Welcome back, {userName}</p>
          </div>
        </div>
        
        <div className="flex items-center bg-purple-900/30 px-4 py-2 rounded-lg border border-purple-500/30">
          <div className="mr-3">
            <p className="text-sm text-gray-300">Available Credits</p>
            <p className="text-2xl font-bold">{userCredits}</p>
          </div>
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1.5 rounded-lg text-sm hover:opacity-90 transition">
            Get More
          </button>
        </div>
        <button 
          onClick={() => {
            logout();
            router.push("/");
          }}
          className="bg-white/10 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-white/20 transition"
        >
          Log Out
        </button>
      </div>
      
      <div className="border-b border-gray-800 mb-6">
        <nav className="flex space-x-8">
          <button
            className={`pb-3 px-1 ${
              activeTab === "projects"
                ? "text-white border-b-2 border-purple-500 font-medium"
                : "text-gray-400 hover:text-gray-300"
            }`}
            onClick={() => setActiveTab("projects")}
          >
            My Projects
          </button>
          <button
            className={`pb-3 px-1 ${
              activeTab === "credits"
                ? "text-white border-b-2 border-purple-500 font-medium"
                : "text-gray-400 hover:text-gray-300"
            }`}
            onClick={() => setActiveTab("credits")}
          >
            Credits History
          </button>
          <button
            className={`pb-3 px-1 ${
              activeTab === "settings"
                ? "text-white border-b-2 border-purple-500 font-medium"
                : "text-gray-400 hover:text-gray-300"
            }`}
            onClick={() => setActiveTab("settings")}
          >
            Settings
          </button>
        </nav>
      </div>
      
      {activeTab === "projects" && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium">Recent Projects</h3>
            <button className="text-purple-400 hover:text-purple-300 text-sm flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              New Project
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Project cards would go here */}
            <div className="border border-gray-800 rounded-lg overflow-hidden bg-black/40">
              <div className="aspect-video bg-gray-900 relative">
                {/* Project thumbnail would go here */}
                <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                  Video
                </div>
              </div>
              <div className="p-4">
                <h4 className="font-medium mb-1">Beach Sunset Animation</h4>
                <p className="text-gray-400 text-sm mb-3">Created 2 days ago</p>
                <div className="flex justify-between">
                  <button className="text-purple-400 hover:text-purple-300 text-sm">
                    Edit
                  </button>
                  <button className="text-gray-400 hover:text-gray-300 text-sm">
                    Share
                  </button>
                </div>
              </div>
            </div>
            
            <div className="border border-gray-800 rounded-lg overflow-hidden bg-black/40">
              <div className="aspect-video bg-gray-900 relative">
                {/* Project thumbnail would go here */}
                <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                  Enhanced
                </div>
              </div>
              <div className="p-4">
                <h4 className="font-medium mb-1">Mountain Landscape</h4>
                <p className="text-gray-400 text-sm mb-3">Created 5 days ago</p>
                <div className="flex justify-between">
                  <button className="text-purple-400 hover:text-purple-300 text-sm">
                    Edit
                  </button>
                  <button className="text-gray-400 hover:text-gray-300 text-sm">
                    Share
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <button className="text-gray-400 hover:text-white text-sm">
              View All Projects
            </button>
          </div>
        </div>
      )}
      
      {activeTab === "credits" && (
        <div>
          <h3 className="text-lg font-medium mb-4">Credits History</h3>
          
          <div className="border border-gray-800 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <div>
                <p className="font-medium">Sign Up Bonus</p>
                <p className="text-gray-400 text-sm">Apr 20, 2025</p>
              </div>
              <p className="text-green-500 font-medium">+1000 credits</p>
            </div>
            
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <div>
                <p className="font-medium">Video Transformation</p>
                <p className="text-gray-400 text-sm">Apr 21, 2025</p>
              </div>
              <p className="text-red-500 font-medium">-100 credits</p>
            </div>
            
            <div className="p-4 border-b border-gray-800 flex justify-between items-center">
              <div>
                <p className="font-medium">Watermark Removal</p>
                <p className="text-gray-400 text-sm">Apr 22, 2025</p>
              </div>
              <p className="text-red-500 font-medium">-50 credits</p>
            </div>
            
            <div className="p-4 flex justify-between items-center">
              <div>
                <p className="font-medium">Referral Bonus</p>
                <p className="text-gray-400 text-sm">Apr 23, 2025</p>
              </div>
              <p className="text-green-500 font-medium">+500 credits</p>
            </div>
          </div>
          
          <div className="mt-6 flex justify-between items-center">
            <p className="text-gray-400">Lifetime credits earned: 1500</p>
            <p className="text-gray-400">Lifetime credits used: 650</p>
          </div>
        </div>
      )}
      
      {activeTab === "settings" && (
        <div>
          <h3 className="text-lg font-medium mb-4">Account Settings</h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                Display Name
              </label>
              <input
                type="text"
                defaultValue={userName}
                className="w-full px-4 py-2 bg-black/60 border border-gray-700 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">
                Email Notifications
              </label>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="notify-projects"
                    defaultChecked
                    className="h-4 w-4 text-purple-600 rounded border-gray-700 focus:ring-purple-500"
                  />
                  <label htmlFor="notify-projects" className="ml-2 text-sm text-gray-300">
                    Project updates and completions
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="notify-credits"
                    defaultChecked
                    className="h-4 w-4 text-purple-600 rounded border-gray-700 focus:ring-purple-500"
                  />
                  <label htmlFor="notify-credits" className="ml-2 text-sm text-gray-300">
                    Credit usage and bonuses
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="notify-news"
                    defaultChecked
                    className="h-4 w-4 text-purple-600 rounded border-gray-700 focus:ring-purple-500"
                  />
                  <label htmlFor="notify-news" className="ml-2 text-sm text-gray-300">
                    New features and updates
                  </label>
                </div>
              </div>
            </div>
            
            <div className="pt-4">
              <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-lg hover:opacity-90 transition">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
