"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { FhotoflipLogo } from "@/components/icons/logo";
import { useFirebase } from "@/context/firebase-context";
import CreditDisplay from "@/components/payment/credit-display";
import { logoutUser } from "@/lib/firebase/auth";

export default function Navbar() {
  const pathname = usePathname();
  const { user, userProfile, loading } = useFirebase();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  
  // Handle scroll effect for navbar
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  const handleLogout = async () => {
    try {
      await logoutUser();
      // Close mobile menu after logout
      setIsMenuOpen(false);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };
  
  const isActive = (path: string) => {
    return pathname === path;
  };
  
  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-black/80 backdrop-blur-lg shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="logo flex items-center">
            <FhotoflipLogo className="h-8 w-auto" />
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            <Link 
              href="/"
              className={`px-4 py-2 rounded-lg transition ${
                isActive("/") 
                  ? "text-white font-medium" 
                  : "text-gray-300 hover:text-white hover:bg-white/5"
              }`}
            >
              Home
            </Link>
            <Link 
              href="/upload"
              className={`px-4 py-2 rounded-lg transition ${
                isActive("/upload") 
                  ? "text-white font-medium" 
                  : "text-gray-300 hover:text-white hover:bg-white/5"
              }`}
            >
              Create
            </Link>
            <Link 
              href="/subscriptions"
              className={`px-4 py-2 rounded-lg transition ${
                isActive("/subscriptions") 
                  ? "text-white font-medium" 
                  : "text-gray-300 hover:text-white hover:bg-white/5"
              }`}
            >
              Pricing
            </Link>
            
            {user ? (
              <>
                <Link 
                  href="/dashboard"
                  className={`px-4 py-2 rounded-lg transition ${
                    isActive("/dashboard") 
                      ? "text-white font-medium" 
                      : "text-gray-300 hover:text-white hover:bg-white/5"
                  }`}
                >
                  Dashboard
                </Link>
                <div className="pl-2 pr-4 py-2">
                  <CreditDisplay />
                </div>
                <Link 
                  href="/buy-credits"
                  className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-2 rounded-lg hover:bg-white/20 transition"
                >
                  Buy Credits
                </Link>
                <button 
                  onClick={handleLogout}
                  className="text-gray-300 px-4 py-2 rounded-lg hover:text-white hover:bg-white/5 transition"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link 
                  href="/login"
                  className="text-gray-300 px-4 py-2 rounded-lg hover:text-white hover:bg-white/5 transition"
                >
                  Login
                </Link>
                <Link 
                  href="/signup"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg hover:opacity-90 transition"
                >
                  Sign Up
                </Link>
              </>
            )}
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-300 hover:text-white"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-black/95 backdrop-blur-lg">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex flex-col space-y-2">
              <Link 
                href="/"
                className={`px-4 py-3 rounded-lg transition ${
                  isActive("/") 
                    ? "bg-white/10 text-white font-medium" 
                    : "text-gray-300 hover:text-white hover:bg-white/5"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                href="/upload"
                className={`px-4 py-3 rounded-lg transition ${
                  isActive("/upload") 
                    ? "bg-white/10 text-white font-medium" 
                    : "text-gray-300 hover:text-white hover:bg-white/5"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Create
              </Link>
              <Link 
                href="/subscriptions"
                className={`px-4 py-3 rounded-lg transition ${
                  isActive("/subscriptions") 
                    ? "bg-white/10 text-white font-medium" 
                    : "text-gray-300 hover:text-white hover:bg-white/5"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                Pricing
              </Link>
              
              {user ? (
                <>
                  <Link 
                    href="/dashboard"
                    className={`px-4 py-3 rounded-lg transition ${
                      isActive("/dashboard") 
                        ? "bg-white/10 text-white font-medium" 
                        : "text-gray-300 hover:text-white hover:bg-white/5"
                    }`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                  <div className="px-4 py-3 flex items-center">
                    <CreditDisplay />
                  </div>
                  <Link 
                    href="/buy-credits"
                    className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-4 py-3 rounded-lg hover:bg-white/20 transition"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Buy Credits
                  </Link>
                  <button 
                    onClick={handleLogout}
                    className="text-gray-300 px-4 py-3 rounded-lg hover:text-white hover:bg-white/5 transition text-left"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link 
                    href="/login"
                    className="text-gray-300 px-4 py-3 rounded-lg hover:text-white hover:bg-white/5 transition"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Login
                  </Link>
                  <Link 
                    href="/signup"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-3 rounded-lg hover:opacity-90 transition"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Sign Up
                  </Link>
                </>
              )}
            </nav>
          </div>
        </div>
      )}
    </header>
  );
}
