"use client";

import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useFirebase } from '@/context/firebase-context';

export default function BreadcrumbNavigation() {
  const pathname = usePathname();
  const { user } = useFirebase();
  const [breadcrumbs, setBreadcrumbs] = useState<{label: string, href: string}[]>([]);
  
  useEffect(() => {
    const generateBreadcrumbs = () => {
      // Remove any query parameters
      const asPathWithoutQuery = pathname.split("?")[0];
      
      // Split pathname into segments
      const segments = asPathWithoutQuery.split('/').filter(segment => segment !== '');
      
      // Map segments to breadcrumb items
      const breadcrumbItems = segments.map((segment, index) => {
        // Build the URL for this breadcrumb
        const href = `/${segments.slice(0, index + 1).join('/')}`;
        
        // Format the label (capitalize first letter, replace hyphens with spaces)
        let label = segment.charAt(0).toUpperCase() + segment.slice(1);
        label = label.replace(/-/g, ' ');
        
        // Special cases for specific routes
        if (segment === 'dashboard' && user) {
          label = 'My Dashboard';
        } else if (segment === 'upload') {
          label = 'Create';
        } else if (segment === 'buy-credits') {
          label = 'Buy Credits';
        }
        
        return { href, label };
      });
      
      // Add Home as the first breadcrumb
      const allBreadcrumbs = [{ href: '/', label: 'Home' }, ...breadcrumbItems];
      setBreadcrumbs(allBreadcrumbs);
    };
    
    generateBreadcrumbs();
  }, [pathname, user]);
  
  // Don't show breadcrumbs on the home page
  if (pathname === '/') {
    return null;
  }
  
  return (
    <nav className="container mx-auto px-4 py-4">
      <ol className="flex flex-wrap items-center text-sm">
        {breadcrumbs.map((breadcrumb, index) => (
          <li key={breadcrumb.href} className="flex items-center">
            {index > 0 && (
              <svg className="mx-2 h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            )}
            {index === breadcrumbs.length - 1 ? (
              <span className="text-white font-medium">{breadcrumb.label}</span>
            ) : (
              <Link 
                href={breadcrumb.href}
                className="text-gray-400 hover:text-white transition"
              >
                {breadcrumb.label}
              </Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
