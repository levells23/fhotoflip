"use client";

import { useState } from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { CreditPackage, formatPrice } from '@/lib/stripe/stripe';
import { useFirebase } from '@/context/firebase-context';
import { addCredits } from '@/lib/firebase/firestore';

interface CheckoutFormProps {
  selectedPackage: CreditPackage;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function CheckoutForm({ selectedPackage, onSuccess, onCancel }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { user } = useFirebase();
  
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [succeeded, setSucceeded] = useState(false);
  
  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!stripe || !elements || !user) {
      return;
    }
    
    setProcessing(true);
    setError(null);
    
    try {
      // In a real implementation, you would call your backend API to create a payment intent
      // For demo purposes, we'll simulate a successful payment
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Add credits to user's account
      await addCredits(user.uid, selectedPackage.credits);
      
      setSucceeded(true);
      setProcessing(false);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'An error occurred during payment processing');
      setProcessing(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-black/40 p-4 rounded-lg mb-4">
        <h3 className="text-lg font-medium mb-2">Order Summary</h3>
        <div className="flex justify-between mb-2">
          <span>{selectedPackage.name} Package</span>
          <span>{formatPrice(selectedPackage.price)}</span>
        </div>
        <div className="flex justify-between text-sm text-gray-400">
          <span>Credits</span>
          <span>{selectedPackage.credits.toLocaleString()}</span>
        </div>
        <div className="border-t border-gray-700 my-2"></div>
        <div className="flex justify-between font-medium">
          <span>Total</span>
          <span>{formatPrice(selectedPackage.price)}</span>
        </div>
      </div>
      
      <div className="space-y-4">
        <label className="block text-sm font-medium text-gray-300">
          Card Details
        </label>
        <div className="bg-black/40 p-4 rounded-lg border border-gray-700">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#ffffff',
                  '::placeholder': {
                    color: '#aab7c4',
                  },
                },
                invalid: {
                  color: '#fa755a',
                  iconColor: '#fa755a',
                },
              },
            }}
          />
        </div>
      </div>
      
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}
      
      <div className="flex space-x-3">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 py-2 px-4 border border-gray-600 rounded-lg hover:bg-gray-800 transition"
          disabled={processing}
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={!stripe || processing || succeeded}
          className={`flex-1 py-2 px-4 rounded-lg font-medium ${
            processing || !stripe
              ? 'bg-purple-700/50 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90'
          } transition flex justify-center items-center`}
        >
          {processing ? (
            <>
              <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </>
          ) : succeeded ? (
            'Payment Successful!'
          ) : (
            `Pay ${formatPrice(selectedPackage.price)}`
          )}
        </button>
      </div>
    </form>
  );
}
