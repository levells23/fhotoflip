"use client";

import { useEffect, useState } from 'react';
import { useFirebase } from '@/context/firebase-context';
import { formatPrice } from '@/lib/stripe/stripe';

export default function CreditDisplay() {
  const { userProfile, loading } = useFirebase();
  const [credits, setCredits] = useState<number | null>(null);
  
  useEffect(() => {
    if (userProfile && !loading) {
      setCredits(userProfile.credits || 0);
    }
  }, [userProfile, loading]);
  
  if (loading) {
    return (
      <div className="flex items-center space-x-2">
        <div className="h-4 w-16 bg-gray-700 animate-pulse rounded"></div>
        <div className="text-gray-500">Credits</div>
      </div>
    );
  }
  
  return (
    <div className="flex items-center space-x-2">
      <div className="font-medium text-purple-400">{credits?.toLocaleString() || 0}</div>
      <div className="text-gray-400">Credits</div>
    </div>
  );
}
