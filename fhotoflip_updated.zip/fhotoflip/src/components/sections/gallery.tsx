"use client";

import Image from "next/image";
import Link from "next/link";

export default function Gallery() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            See what's possible with Fhotoflip
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore stunning transformations created by our users and see the power of our AI technology in action.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Gallery items would normally have real images */}
          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Nature in Motion</h3>
              <p className="text-sm text-gray-300">Photo to video transformation</p>
            </div>
            <div className="absolute top-4 right-4 bg-purple-600 text-white text-xs px-2 py-1 rounded-full z-20">
              Featured
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>

          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Urban Landscape</h3>
              <p className="text-sm text-gray-300">Enhanced cityscape with movement</p>
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>

          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Portrait Animation</h3>
              <p className="text-sm text-gray-300">Subtle facial animations</p>
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>

          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Before & After</h3>
              <p className="text-sm text-gray-300">Watermark removal showcase</p>
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>

          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Ocean Waves</h3>
              <p className="text-sm text-gray-300">Dynamic water movement</p>
            </div>
            <div className="absolute top-4 right-4 bg-pink-600 text-white text-xs px-2 py-1 rounded-full z-20">
              Popular
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>

          <div className="group relative overflow-hidden rounded-xl aspect-video bg-gray-900 cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent z-10"></div>
            <div className="absolute bottom-0 left-0 p-4 z-20">
              <h3 className="text-xl font-bold">Short Film</h3>
              <p className="text-sm text-gray-300">Created with filmmaking tools</p>
            </div>
            <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10"></div>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link 
            href="/gallery" 
            className="bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-3 rounded-full text-lg font-medium hover:bg-white/20 transition inline-block"
          >
            View More Examples
          </Link>
        </div>
      </div>
    </section>
  );
}
