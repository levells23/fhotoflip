"use client";

import Image from "next/image";
import Link from "next/link";

export default function Features() {
  return (
    <section className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Technology for a new era <br />
            of photo transformation.
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Fhotoflip is a global AI platform working with cutting-edge technology to transform static images into dynamic content. We build foundational AI models and creative tools that are empowering a new creative paradigm.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-20">
          <div className="bg-gradient-to-br from-black to-purple-900/20 p-8 rounded-xl border border-purple-500/20">
            <h3 className="text-2xl font-bold mb-4">Photo to Video Conversion</h3>
            <p className="text-gray-300 mb-6">
              Transform your static images into dynamic videos with natural motion and lifelike animations. Our AI understands the context of your image and creates realistic movement.
            </p>
            <Link 
              href="/features/photo-to-video" 
              className="text-purple-400 hover:text-purple-300 font-medium flex items-center"
            >
              Learn more
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </Link>
          </div>

          <div className="bg-gradient-to-br from-black to-pink-900/20 p-8 rounded-xl border border-pink-500/20">
            <h3 className="text-2xl font-bold mb-4">Watermark Removal</h3>
            <p className="text-gray-300 mb-6">
              Easily remove unwanted watermarks from your images with our advanced AI technology. Restore your photos to their original quality without any visible artifacts.
            </p>
            <Link 
              href="/features/watermark-removal" 
              className="text-pink-400 hover:text-pink-300 font-medium flex items-center"
            >
              Learn more
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </Link>
          </div>

          <div className="bg-gradient-to-br from-black to-blue-900/20 p-8 rounded-xl border border-blue-500/20">
            <h3 className="text-2xl font-bold mb-4">Image Enhancement</h3>
            <p className="text-gray-300 mb-6">
              Enhance your photos with our AI-powered tools. Improve quality, adjust lighting, increase resolution, and make your images look professional with just a few clicks.
            </p>
            <Link 
              href="/features/image-enhancement" 
              className="text-blue-400 hover:text-blue-300 font-medium flex items-center"
            >
              Learn more
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </Link>
          </div>

          <div className="bg-gradient-to-br from-black to-green-900/20 p-8 rounded-xl border border-green-500/20">
            <h3 className="text-2xl font-bold mb-4">Filmmaking Tools</h3>
            <p className="text-gray-300 mb-6">
              Create professional-looking videos with our filmmaking tools. Add effects, transitions, text, and music to your transformed photos and create compelling visual stories.
            </p>
            <Link 
              href="/features/filmmaking" 
              className="text-green-400 hover:text-green-300 font-medium flex items-center"
            >
              Learn more
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
