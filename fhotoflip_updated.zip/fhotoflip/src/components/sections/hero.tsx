"use client";

import Link from "next/link";
import Image from "next/image";

export default function Hero() {
  return (
    <section className="relative pt-24 pb-16 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-black/90 to-black z-10"></div>
        <div className="absolute inset-0 bg-[url('/images/hero-bg.jpg')] bg-cover bg-center opacity-50 z-0"></div>
      </div>
      
      <div className="container mx-auto px-4 pt-16 relative z-20">
        <div className="flex flex-col items-center text-center mb-12">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-300">
            Transform Your Photos
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mb-8">
            Create stunning videos, animations, and visual effects from your static images with AI-powered tools.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              href="/get-started" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full text-lg font-medium hover:opacity-90 transition"
            >
              Try Fhotoflip Now
            </Link>
            <Link 
              href="/features" 
              className="bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-3 rounded-full text-lg font-medium hover:bg-white/20 transition"
            >
              Learn More
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-xl p-6 hover:border-purple-500/50 transition cursor-pointer group">
            <h3 className="text-2xl font-bold mb-2 group-hover:text-purple-400 transition">Photo to Video</h3>
            <p className="text-gray-400">Transform static images into dynamic videos with natural motion and effects.</p>
          </div>
          
          <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-xl p-6 hover:border-purple-500/50 transition cursor-pointer group">
            <h3 className="text-2xl font-bold mb-2 group-hover:text-purple-400 transition">AI Enhancement</h3>
            <p className="text-gray-400">Enhance image quality, remove watermarks, and improve visual appeal.</p>
          </div>
          
          <div className="bg-black/40 backdrop-blur-md border border-white/10 rounded-xl p-6 hover:border-purple-500/50 transition cursor-pointer group">
            <h3 className="text-2xl font-bold mb-2 group-hover:text-purple-400 transition">Creative Collaboration</h3>
            <p className="text-gray-400">Share and collaborate on projects with friends and colleagues.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
