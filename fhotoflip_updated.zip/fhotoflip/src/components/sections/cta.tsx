"use client";

import Image from "next/image";
import Link from "next/link";

export default function CTA() {
  return (
    <section className="py-20 bg-gradient-to-b from-black to-purple-900/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Ready to transform your photos?
          </h2>
          <p className="text-xl text-gray-300 mb-10">
            Sign up today and get 1000 free credits to start creating amazing videos and animations from your photos.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/signup" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full text-lg font-medium hover:opacity-90 transition"
            >
              Get Started Free
            </Link>
            <Link 
              href="/demo" 
              className="bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-3 rounded-full text-lg font-medium hover:bg-white/20 transition"
            >
              Watch Demo
            </Link>
          </div>
          <p className="text-gray-400 mt-6">
            No credit card required. Get 500 additional credits by sharing with friends.
          </p>
        </div>
      </div>
    </section>
  );
}
