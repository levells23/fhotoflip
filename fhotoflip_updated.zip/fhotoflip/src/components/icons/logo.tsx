import { createSvgIcon } from "@/lib/create-svg-icon";

export const FhotoflipLogo = createSvgIcon(
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 50" fill="none">
    <path d="M20 10h30v5H25v10h20v5H25v10h25v5H20V10z" fill="url(#paint0_linear)" />
    <path d="M60 10h5v35h-5V10z" fill="url(#paint1_linear)" />
    <path d="M70 10h5v15c0 5 2.5 10 10 10s10-5 10-10V10h5v15c0 7.5-5 15-15 15s-15-7.5-15-15V10z" fill="url(#paint2_linear)" />
    <path d="M105 10h5v15l15-15h7.5L117.5 25l15 20H125l-15-20v20h-5V10z" fill="url(#paint3_linear)" />
    <path d="M135 10h5v15c0 5 2.5 10 10 10s10-5 10-10V10h5v15c0 7.5-5 15-15 15s-15-7.5-15-15V10z" fill="url(#paint4_linear)" />
    <path d="M170 10h5v30h20v5h-25V10z" fill="url(#paint5_linear)" />
    <circle cx="190" cy="15" r="5" fill="url(#paint6_linear)" />
    <defs>
      <linearGradient id="paint0_linear" x1="20" y1="25" x2="50" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint1_linear" x1="60" y1="25" x2="65" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint2_linear" x1="70" y1="25" x2="100" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint3_linear" x1="105" y1="25" x2="132.5" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint4_linear" x1="135" y1="25" x2="165" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint5_linear" x1="170" y1="25" x2="195" y2="25" gradientUnits="userSpaceOnUse">
        <stop stopColor="#f5f5f5" />
        <stop offset="1" stopColor="#a855f7" />
      </linearGradient>
      <linearGradient id="paint6_linear" x1="185" y1="15" x2="195" y2="15" gradientUnits="userSpaceOnUse">
        <stop stopColor="#a855f7" />
        <stop offset="1" stopColor="#ec4899" />
      </linearGradient>
    </defs>
  </svg>,
  "FhotoflipLogo"
);
