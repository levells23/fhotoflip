"use client";

import { useState } from "react";
import { FhotoflipLogo } from "@/components/icons/logo";
import PhotoProcessingService from "@/lib/photo-processing";
import { useAuthContext } from "@/context/auth-context";
import { useRouter } from "next/navigation";

export default function UploadForm() {
  const router = useRouter();
  const { user } = useAuthContext();
  const photoProcessing = PhotoProcessingService();
  
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [processingOption, setProcessingOption] = useState<'video' | 'watermark' | 'enhance' | 'film'>('video');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ success: boolean; resultUrl?: string } | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (file.type.startsWith('image/')) {
      setSelectedFile(file);
      setResult(null);
      setError(null);
      
      const reader = new FileReader();
      reader.onload = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleProcessPhoto = async () => {
    if (!user) {
      router.push('/login');
      return;
    }
    
    if (!selectedFile) return;
    
    setIsProcessing(true);
    setError(null);
    
    try {
      const result = await photoProcessing.processPhoto(selectedFile, processingOption);
      setResult(result);
      
      if (!result.success) {
        setError(result.error);
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const processingOptions = [
    { id: "video" as const, label: "Photo to Video" },
    { id: "watermark" as const, label: "Watermark Removal" },
    { id: "enhance" as const, label: "Image Enhancement" },
    { id: "film" as const, label: "Filmmaking Tools" }
  ];

  return (
    <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8 max-w-3xl w-full mx-auto">
      <div className="flex items-center justify-center mb-6">
        <FhotoflipLogo className="h-8 w-auto mr-2" />
        <h2 className="text-2xl font-bold">Transform Your Photo</h2>
      </div>
      
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      {result && result.success && (
        <div className="bg-green-500/10 border border-green-500/30 text-green-400 px-4 py-3 rounded-lg mb-6">
          <p className="font-medium mb-2">Transformation complete!</p>
          <p>Your photo has been successfully processed.</p>
          <div className="mt-4 flex justify-end">
            <button 
              onClick={() => router.push('/dashboard')}
              className="text-white bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg text-sm"
            >
              View in Dashboard
            </button>
          </div>
        </div>
      )}
      
      {!selectedFile ? (
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center ${
            isDragging ? "border-purple-500 bg-purple-500/10" : "border-gray-600"
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="mx-auto mb-4">
            <svg
              className="mx-auto h-12 w-12 text-gray-400"
              stroke="currentColor"
              fill="none"
              viewBox="0 0 48 48"
              aria-hidden="true"
            >
              <path
                d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <p className="text-lg mb-2">Drag and drop your photo here</p>
          <p className="text-gray-400 mb-4">or</p>
          <label className="btn-primary cursor-pointer inline-block">
            Browse Files
            <input
              type="file"
              className="hidden"
              accept="image/*"
              onChange={handleFileInput}
            />
          </label>
          <p className="text-gray-400 mt-4 text-sm">
            Supported formats: JPG, PNG, WEBP (Max 10MB)
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="relative aspect-video rounded-lg overflow-hidden bg-gray-900">
            {preview && (
              <img
                src={preview}
                alt="Preview"
                className="w-full h-full object-contain"
              />
            )}
            <button
              onClick={() => {
                setSelectedFile(null);
                setPreview(null);
                setResult(null);
              }}
              className="absolute top-2 right-2 bg-black/60 text-white p-1 rounded-full"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-3">Choose transformation:</h3>
            <div className="grid grid-cols-2 gap-3">
              {processingOptions.map((option) => (
                <button
                  key={option.id}
                  className={`p-3 rounded-lg border text-left ${
                    processingOption === option.id
                      ? "border-purple-500 bg-purple-500/10"
                      : "border-gray-700 hover:border-gray-500"
                  }`}
                  onClick={() => setProcessingOption(option.id)}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <button 
            className={`w-full py-3 rounded-lg font-medium flex justify-center items-center ${
              isProcessing 
                ? "bg-gray-700 text-gray-300 cursor-not-allowed" 
                : "btn-primary"
            }`}
            onClick={handleProcessPhoto}
            disabled={isProcessing}
          >
            {isProcessing ? (
              <>
                <svg className="animate-spin h-5 w-5 mr-3" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : (
              `Transform Now (Uses ${
                processingOption === 'video' ? '100' : 
                processingOption === 'watermark' ? '50' : 
                processingOption === 'enhance' ? '75' : '150'
              } Credits)`
            )}
          </button>
        </div>
      )}
    </div>
  );
}
