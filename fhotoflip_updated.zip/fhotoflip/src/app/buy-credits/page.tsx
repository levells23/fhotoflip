"use client";

import { useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { stripePromise, creditPackages, CreditPackage } from '@/lib/stripe/stripe';
import CheckoutForm from '@/components/payment/checkout-form';
import { FhotoflipLogo } from '@/components/icons/logo';

export default function BuyCreditsPage() {
  const [selectedPackage, setSelectedPackage] = useState<CreditPackage | null>(null);
  const [checkoutComplete, setCheckoutComplete] = useState(false);
  
  const handlePackageSelect = (pkg: CreditPackage) => {
    setSelectedPackage(pkg);
  };
  
  const handleCheckoutSuccess = () => {
    setCheckoutComplete(true);
  };
  
  const handleCheckoutCancel = () => {
    setSelectedPackage(null);
  };
  
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl">
      <div className="text-center mb-12">
        <FhotoflipLogo className="h-10 w-auto mx-auto mb-4" />
        <h1 className="text-3xl font-bold mb-2">Buy Credits</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Purchase credits to use for photo transformations, video generation, watermark removal, and more.
        </p>
      </div>
      
      {checkoutComplete ? (
        <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 text-green-400 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-2">Payment Successful!</h2>
          <p className="text-gray-300 mb-6">
            Your credits have been added to your account and are ready to use.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/dashboard" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition"
            >
              Go to Dashboard
            </a>
            <a 
              href="/upload" 
              className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-6 py-3 rounded-lg hover:bg-white/20 transition"
            >
              Start Creating
            </a>
          </div>
        </div>
      ) : selectedPackage ? (
        <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold mb-6">Checkout</h2>
          <Elements stripe={stripePromise}>
            <CheckoutForm 
              selectedPackage={selectedPackage} 
              onSuccess={handleCheckoutSuccess} 
              onCancel={handleCheckoutCancel} 
            />
          </Elements>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {creditPackages.map((pkg) => (
            <div 
              key={pkg.id}
              className={`bg-black/60 backdrop-blur-sm border rounded-xl p-6 flex flex-col ${
                pkg.popular 
                  ? 'border-purple-500 ring-2 ring-purple-500/20' 
                  : 'border-white/10 hover:border-white/30'
              } transition cursor-pointer`}
              onClick={() => handlePackageSelect(pkg)}
            >
              {pkg.popular && (
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full self-start mb-4">
                  Most Popular
                </div>
              )}
              
              <h3 className="text-xl font-bold mb-1">{pkg.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{pkg.description}</p>
              
              <div className="text-3xl font-bold mb-2">${(pkg.price / 100).toFixed(2)}</div>
              <div className="text-purple-400 font-medium mb-6">{pkg.credits.toLocaleString()} Credits</div>
              
              <button 
                className="mt-auto bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg hover:opacity-90 transition"
                onClick={() => handlePackageSelect(pkg)}
              >
                Select Package
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
