"use client";

import Navbar from "@/components/ui/navbar";
import Footer from "@/components/ui/footer";
import UserDashboard from "@/components/dashboard/user-dashboard";

export default function DashboardPage() {
  return (
    <>
      <Navbar />
      <div className="min-h-screen pt-24 pb-16 bg-gradient-to-b from-black to-purple-900/20">
        <div className="container mx-auto px-4 py-16">
          <UserDashboard />
        </div>
      </div>
      <Footer />
    </>
  );
}
