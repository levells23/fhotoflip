"use client";

import { useState } from "react";
import Navbar from "@/components/ui/navbar";
import Footer from "@/components/ui/footer";
import SignupForm from "@/components/forms/signup-form";

export default function SignupPage() {
  return (
    <>
      <Navbar />
      <div className="min-h-screen pt-24 pb-16 bg-gradient-to-b from-black to-purple-900/20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-md mx-auto text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Join Fhotoflip</h1>
            <p className="text-gray-300">
              Create an account to get 1000 free credits and start transforming your photos today.
            </p>
          </div>
          
          <SignupForm />
          
          <div className="mt-12 max-w-md mx-auto text-center">
            <h3 className="text-xl font-semibold mb-4">Get 500 bonus credits</h3>
            <p className="text-gray-400">
              Share Fhotoflip with your friends and earn 500 additional credits when they sign up.
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
