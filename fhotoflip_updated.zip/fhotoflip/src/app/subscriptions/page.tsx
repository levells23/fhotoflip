"use client";

import { useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { stripePromise, subscriptionPlans, SubscriptionPlan, formatPrice } from '@/lib/stripe/stripe';
import { FhotoflipLogo } from '@/components/icons/logo';

export default function SubscriptionsPage() {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [subscriptionComplete, setSubscriptionComplete] = useState(false);
  
  const handlePlanSelect = (plan: SubscriptionPlan) => {
    // In a real implementation, this would redirect to a Stripe Checkout session
    // For demo purposes, we'll simulate a successful subscription
    setSelectedPlan(plan);
    setTimeout(() => {
      setSubscriptionComplete(true);
    }, 1500);
  };
  
  return (
    <div className="container mx-auto px-4 py-16 max-w-5xl">
      <div className="text-center mb-12">
        <FhotoflipLogo className="h-10 w-auto mx-auto mb-4" />
        <h1 className="text-3xl font-bold mb-2">Subscription Plans</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Subscribe to get monthly credits and premium features for your Fhotoflip experience.
        </p>
      </div>
      
      {subscriptionComplete && selectedPlan ? (
        <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/20 text-green-400 mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold mb-2">Subscription Activated!</h2>
          <p className="text-gray-300 mb-2">
            You are now subscribed to the {selectedPlan.name} plan.
          </p>
          <p className="text-purple-400 font-medium mb-6">
            {selectedPlan.creditsPerMonth.toLocaleString()} credits have been added to your account.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/dashboard" 
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg hover:opacity-90 transition"
            >
              Go to Dashboard
            </a>
            <a 
              href="/upload" 
              className="bg-white/10 backdrop-blur-sm border border-white/20 text-white px-6 py-3 rounded-lg hover:bg-white/20 transition"
            >
              Start Creating
            </a>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {subscriptionPlans.map((plan) => (
            <div 
              key={plan.id}
              className={`bg-black/60 backdrop-blur-sm border rounded-xl p-8 flex flex-col ${
                plan.popular 
                  ? 'border-purple-500 ring-2 ring-purple-500/20' 
                  : 'border-white/10 hover:border-white/30'
              } transition`}
            >
              {plan.popular && (
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-xs font-bold uppercase tracking-wider py-1 px-3 rounded-full self-start mb-4">
                  Most Popular
                </div>
              )}
              
              <h3 className="text-2xl font-bold mb-1">{plan.name}</h3>
              <div className="flex items-baseline mb-6">
                <span className="text-3xl font-bold">{formatPrice(plan.price)}</span>
                <span className="text-gray-400 ml-1">/month</span>
              </div>
              
              <div className="text-purple-400 font-medium mb-4">
                {plan.creditsPerMonth.toLocaleString()} credits per month
              </div>
              
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <svg className="h-5 w-5 text-green-400 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button 
                className="mt-auto bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-4 rounded-lg hover:opacity-90 transition"
                onClick={() => handlePlanSelect(plan)}
              >
                Subscribe Now
              </button>
            </div>
          ))}
        </div>
      )}
      
      <div className="mt-12 text-center">
        <p className="text-gray-400 mb-4">
          Prefer to pay as you go? You can also purchase credits individually.
        </p>
        <a 
          href="/buy-credits"
          className="inline-block bg-white/10 backdrop-blur-sm border border-white/20 text-white px-6 py-3 rounded-lg hover:bg-white/20 transition"
        >
          Buy Credits
        </a>
      </div>
    </div>
  );
}
