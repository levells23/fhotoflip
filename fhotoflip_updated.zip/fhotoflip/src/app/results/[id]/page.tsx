"use client";

import Navbar from "@/components/ui/navbar";
import Footer from "@/components/ui/footer";
import ResultsPageContent from "@/components/results/results-page-content";

export default function ResultsPage({ 
  params 
}: { 
  params: { id: string } 
}) {
  // In a real application, we would fetch the result details from an API
  // For demo purposes, we'll use mock data
  const resultUrl = `/api/results/${params.id}`;
  const processingType = params.id.startsWith('video') ? 'video' : 
                         params.id.startsWith('watermark') ? 'watermark' :
                         params.id.startsWith('enhanced') ? 'enhance' : 'film';

  return (
    <>
      <Navbar />
      <div className="min-h-screen pt-24 pb-16 bg-gradient-to-b from-black to-purple-900/20">
        <div className="container mx-auto px-4 py-16">
          <ResultsPageContent resultUrl={resultUrl} processingType={processingType} />
        </div>
      </div>
      <Footer />
    </>
  );
}
