"use client";

import Navbar from "@/components/ui/navbar";
import Footer from "@/components/ui/footer";
import LoginForm from "@/components/forms/login-form";

export default function LoginPage() {
  return (
    <>
      <Navbar />
      <div className="min-h-screen pt-24 pb-16 bg-gradient-to-b from-black to-purple-900/20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-md mx-auto text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Welcome Back</h1>
            <p className="text-gray-300">
              Log in to your Fhotoflip account to access your projects and credits.
            </p>
          </div>
          
          <LoginForm />
        </div>
      </div>
      <Footer />
    </>
  );
}
