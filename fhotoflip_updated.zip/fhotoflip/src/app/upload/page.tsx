"use client";

import Navbar from "@/components/ui/navbar";
import Footer from "@/components/ui/footer";
import UploadForm from "@/components/forms/upload-form";

export default function UploadPage() {
  return (
    <>
      <Navbar />
      <div className="min-h-screen pt-24 pb-16 bg-gradient-to-b from-black to-purple-900/20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h1 className="text-3xl font-bold mb-4">Transform Your Photos</h1>
            <p className="text-gray-300">
              Upload your photos and use our AI-powered tools to create videos, remove watermarks, enhance images, and more.
            </p>
          </div>
          
          <UploadForm />
          
          <div className="mt-12 max-w-3xl mx-auto text-center">
            <h3 className="text-xl font-semibold mb-4">Share Your Creations</h3>
            <p className="text-gray-400">
              After transforming your photos, easily share them on social media or download them for personal use.
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
