"use client";

import { useState } from "react";
import Link from "next/link";
import { FhotoflipLogo } from "@/components/icons/logo";

export default function SharePage({ 
  params 
}: { 
  params: { id: string } 
}) {
  const [copied, setCopied] = useState(false);
  const shareUrl = `https://fhotoflip.com/share/${params.id}`;
  
  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-purple-900/20 flex flex-col">
      <header className="py-6 border-b border-white/10">
        <div className="container mx-auto px-4 flex justify-center">
          <Link href="/" className="logo flex items-center">
            <FhotoflipLogo className="h-8 w-auto" />
          </Link>
        </div>
      </header>
      
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="bg-black/60 backdrop-blur-sm border border-white/10 rounded-xl p-8 max-w-md w-full mx-auto text-center">
          <FhotoflipLogo className="h-12 w-auto mx-auto mb-6" />
          
          <h1 className="text-2xl font-bold mb-2">Someone shared a Fhotoflip creation with you!</h1>
          <p className="text-gray-300 mb-8">
            Check out this amazing transformation created with Fhotoflip's AI-powered tools.
          </p>
          
          <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden mb-8">
            {/* This would be the actual shared content in a real implementation */}
            <div className="w-full h-full flex items-center justify-center">
              <p className="text-gray-400">Preview image for {params.id}</p>
            </div>
          </div>
          
          <div className="flex flex-col space-y-4">
            <Link 
              href="/"
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full text-lg font-medium hover:opacity-90 transition"
            >
              Create Your Own
            </Link>
            
            <div className="flex">
              <input 
                type="text" 
                value={shareUrl} 
                readOnly
                className="flex-1 bg-black/60 border border-gray-700 rounded-l-lg px-3 py-2"
              />
              <button 
                onClick={handleCopyLink}
                className={`${copied ? 'bg-green-600' : 'bg-purple-600'} text-white px-4 py-2 rounded-r-lg hover:opacity-90 transition`}
              >
                {copied ? 'Copied!' : 'Copy Link'}
              </button>
            </div>
          </div>
          
          <p className="mt-8 text-sm text-gray-400">
            Sign up for Fhotoflip and get 1000 free credits to create your own transformations!
          </p>
        </div>
      </main>
      
      <footer className="py-6 border-t border-white/10 text-center text-gray-400 text-sm">
        © 2025 Fhotoflip. All rights reserved.
      </footer>
    </div>
  );
}
