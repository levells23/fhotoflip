import Navbar from "@/components/ui/navbar";
import Hero from "@/components/sections/hero";
import Features from "@/components/sections/features";
import Gallery from "@/components/sections/gallery";
import Pricing from "@/components/sections/pricing";
import CTA from "@/components/sections/cta";
import Footer from "@/components/ui/footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      <Features />
      <Gallery />
      <Pricing />
      <CTA />
      <Footer />
    </>
  );
}
