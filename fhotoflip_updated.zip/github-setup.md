# GitHub Setup for Fhotoflip

This document provides instructions for setting up GitHub repository for the Fhotoflip project, including version control and continuous integration/deployment.

## Repository Setup

1. Create a new GitHub repository named "fhotoflip"
2. Initialize the repository with a README.md file
3. Add .gitignore file for Node.js projects
4. Add MIT license (or your preferred license)

## Local Git Setup

```bash
# Navigate to your project directory
cd /home/ubuntu/fhotoflip/fhotoflip

# Initialize git repository
git init

# Add all files to staging
git add .

# Create initial commit
git commit -m "Initial commit: Fhotoflip website"

# Add GitHub remote (replace with your actual GitHub repository URL)
git remote add origin https://github.com/yourusername/fhotoflip.git

# Push to GitHub
git push -u origin main
```

## GitHub Actions for CI/CD

Create a GitHub Actions workflow file at `.github/workflows/deploy.yml`:

```yaml
name: Deploy Fhotoflip

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build
      run: npm run build
      
    - name: Test
      run: npm test
      
  deploy:
    needs: build
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Build
      run: npm run build
      
    - name: Deploy to production
      uses: FirebaseExtended/action-hosting-deploy@v0
      with:
        repoToken: '${{ secrets.GITHUB_TOKEN }}'
        firebaseServiceAccount: '${{ secrets.FIREBASE_SERVICE_ACCOUNT }}'
        channelId: live
        projectId: your-firebase-project-id
```

## Environment Variables

Create a `.env.example` file to document required environment variables:

```
# Firebase Configuration
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=

# Stripe Configuration
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_SECRET_KEY=
```

## GitHub Repository Settings

1. Configure branch protection rules for the main branch
2. Set up required status checks before merging
3. Configure GitHub Secrets for environment variables
4. Set up GitHub Pages or other deployment options

## Collaboration Workflow

1. Create feature branches for new features
2. Submit pull requests for code review
3. Merge approved pull requests to main branch
4. Automated deployment via GitHub Actions
